package notinheap

//go:notinheap
type S struct{}
